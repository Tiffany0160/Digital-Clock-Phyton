import tkinter as tk
from time import strftime

def update_time():
    current_time = strftime('%H:%M:%S %p')
    label.config(text=current_time)
    label.after(1000, update_time)

app = tk.Tk()
app.title("Digital Clock")
app.geometry("300x150")
app.configure(bg="black")  # Black background

label = tk.Label(app, font=("Arial", 48), bg="black", fg="cyan")  # Cyan text
label.pack(anchor="center", pady=20)

update_time()

app.mainloop()
